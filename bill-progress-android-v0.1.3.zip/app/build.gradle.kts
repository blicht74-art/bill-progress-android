plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.billlicht.progress"; compileSdk=36
 defaultConfig { applicationId="com.billlicht.progress"; minSdk=34; targetSdk=35; versionCode=4; versionName="0.1.3" }
 compileOptions { sourceCompatibility=JavaVersion.VERSION_17; targetCompatibility=JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget="17" }
}
dependencies { implementation("androidx.activity:activity-ktx:1.10.1"); implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.1"); implementation("androidx.health.connect:connect-client:1.1.0"); implementation("androidx.work:work-runtime-ktx:2.10.1") }
